# Test info

- Name: Validação de Checkout no SauceDemo >> Deve exibir erro para CEP com caracteres especiais
- Location: C:\Users\kayki\Documents\playwright\tests\TestLimiteCaracter.spec.ts:94:7

# Error details

```
Error: Timed out 5000ms waiting for expect(locator).toBeVisible()

Locator: locator('[data-test="error"]')
Expected: visible
Received: <element(s) not found>
Call log:
  - expect.toBeVisible with timeout 5000ms
  - waiting for locator('[data-test="error"]')

    at C:\Users\kayki\Documents\playwright\tests\TestLimiteCaracter.spec.ts:101:25
```

# Page snapshot

```yaml
- button "Open Menu"
- img "Open Menu"
- text: "Swag Labs 1 Checkout: Overview QTY Description 1"
- link "Sauce Labs Backpack":
  - /url: "#"
- text: "carry.allTheThings() with the sleek, streamlined Sly Pack that melds uncompromising style with unequaled laptop and tablet protection. $29.99 Payment Information: SauceCard #31337 Shipping Information: Free Pony Express Delivery! Price Total Item total: $29.99 Tax: $2.40 Total: $32.39"
- button "Go back Cancel":
  - img "Go back"
  - text: Cancel
- button "Finish"
- contentinfo:
  - list:
    - listitem:
      - link "Twitter":
        - /url: https://twitter.com/saucelabs
    - listitem:
      - link "Facebook":
        - /url: https://www.facebook.com/saucelabs
    - listitem:
      - link "LinkedIn":
        - /url: https://www.linkedin.com/company/sauce-labs/
  - text: © 2025 Sauce Labs. All Rights Reserved. Terms of Service | Privacy Policy
```

# Test source

```ts
   1 | import { test, expect } from '@playwright/test';
   2 |
   3 | test.describe('Validação de Checkout no SauceDemo', () => {
   4 |   const loginUrl = 'https://www.saucedemo.com';
   5 |
   6 |   /**
   7 |    * Função auxiliar para gerar strings de tamanho específico
   8 |    * @param tamanho - Quantidade de caracteres da string a ser gerada
   9 |    * @returns String preenchida com o caractere 'A' repetido pelo tamanho especificado
   10 |    */
   11 |   const gerarString = (tamanho: number) => 'A'.repeat(tamanho);
   12 |
   13 |   test.beforeEach(async ({ page }) => {
   14 |     // 1. Navega para página de login
   15 |     await page.goto(loginUrl);
   16 |     
   17 |     // 2. Preenche credenciais e faz login
   18 |     await page.fill('#user-name', 'standard_user');
   19 |     await page.fill('#password', 'secret_sauce');
   20 |     await page.click('#login-button');
   21 |     
   22 |     // 3. Verifica se foi redirecionado para a página de produtos
   23 |     await expect(page).toHaveURL(/inventory/);
   24 |     
   25 |     // 4. Adiciona produto ao carrinho e navega para checkout
   26 |     await page.click('text=Add to cart');       // Clica no primeiro botão "Add to cart"
   27 |     await page.click('.shopping_cart_link');   // Abre o carrinho
   28 |     await page.click('text=Checkout');         // Inicia o checkout
   29 |     
   30 |     // 5. Verifica se chegou na primeira etapa do checkout
   31 |     await expect(page).toHaveURL(/checkout-step-one/);
   32 |   });
   33 |
   34 |   
   35 |   //Teste do caminho feliz de preenchimento válido
   36 |   test('Deve permitir preenchimento válido', async ({ page }) => {
   37 |     // Preenche formulário com dados válidos
   38 |     await page.fill('#first-name', 'João');
   39 |     await page.fill('#last-name', 'Silva');
   40 |     await page.fill('#postal-code', '12345678');
   41 |     
   42 |     // Submete o formulário
   43 |     await page.click('#continue');
   44 |     
   45 |     // Verifica se avançou para etapa 2 do checkout
   46 |     await expect(page).toHaveURL(/checkout-step-two/);
   47 |   });
   48 |
   49 |
   50 |   //Teste simulando erro do primeiro nome muito longo (151 caracteres)
   51 |   test('Deve exibir erro para primeiro nome excedendo limite (151)', async ({ page }) => {
   52 |     // Preenche formulário com primeiro nome inválido (151 caracteres)
   53 |     await page.fill('#first-name', gerarString(151));
   54 |     await page.fill('#last-name', 'Silva');
   55 |     await page.fill('#postal-code', '12345678');
   56 |     
   57 |     // Submete o formulário
   58 |     await page.click('#continue');
   59 |     
   60 |     // Localiza e valida mensagem de erro
   61 |     const error = page.locator('[data-test="error"]');
   62 |     await expect(error).toBeVisible(); // Verifica se erro está visível
   63 |     await expect(error).toContainText('First Name'); // Verifica se mensagem menciona o campo
   64 |   });
   65 |
   66 |
   67 |   //Teste simulando erro do último nome muito longo (251 caracteres)
   68 |   test('Deve exibir erro para último nome excedendo limite (251)', async ({ page }) => {
   69 |     await page.fill('#first-name', 'João');
   70 |     await page.fill('#last-name', gerarString(251)); // Último nome inválido
   71 |     await page.fill('#postal-code', '12345678');
   72 |     await page.click('#continue');
   73 |     
   74 |     const error = page.locator('[data-test="error"]');
   75 |     await expect(error).toBeVisible();
   76 |     await expect(error).toContainText('Last Name'); // Mensagem específica para último nome
   77 |   });
   78 |
   79 |   
   80 |    // Teste simulando erro do CEP incompleto (7 caracteres)
   81 |   test('Deve exibir erro para CEP com menos de 8 caracteres', async ({ page }) => {
   82 |     await page.fill('#first-name', 'João');
   83 |     await page.fill('#last-name', 'Silva');
   84 |     await page.fill('#postal-code', '1234567'); // CEP com apenas 7 caracteres
   85 |     await page.click('#continue');
   86 |     
   87 |     const error = page.locator('[data-test="error"]');
   88 |     await expect(error).toBeVisible();
   89 |     await expect(error).toContainText('Postal Code'); // Mensagem específica para CEP
   90 |   });
   91 |
   92 |   
   93 |   // Teste simulando erro do CEP com caracteres especiais
   94 |   test('Deve exibir erro para CEP com caracteres especiais', async ({ page }) => {
   95 |     await page.fill('#first-name', 'João');
   96 |     await page.fill('#last-name', 'Silva');
   97 |     await page.fill('#postal-code', '12@#5678'); // CEP com caracteres inválidos
   98 |     await page.click('#continue');
   99 |     
  100 |     const error = page.locator('[data-test="error"]');
> 101 |     await expect(error).toBeVisible();
      |                         ^ Error: Timed out 5000ms waiting for expect(locator).toBeVisible()
  102 |     await expect(error).toContainText('Postal Code');
  103 |   });
  104 | });
```